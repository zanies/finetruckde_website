#!/bin/bash

# Sprawdź czy ImageMagick (komenda convert) jest dostępna
if ! command -v convert &> /dev/null; then
    echo "Błąd: ImageMagick (komenda 'convert') nie została znaleziona."
    echo "Zainstaluj ją za pomocą: brew install imagemagick"
    exit 1
fi

shopt -s nullglob

total_orig_size=0
total_webp_size=0
count=0

# Funkcja do pobierania rozmiaru pliku w bajtach (kompatybilna z macOS i Linux)
get_file_size() {
    if [[ "$OSTYPE" == "darwin"* ]]; then
        stat -f%z "$1"
    else
        stat -c%s "$1"
    fi
}

# Funkcja do formatowania bajtów na czytelny format (KB/MB)
format_size() {
    local size=$1
    if [ $size -ge 1048576 ]; then
        echo "$(echo "scale=2; $size/1048576" | bc) MB"
    elif [ $size -ge 1024 ]; then
        echo "$(echo "scale=2; $size/1024" | bc) KB"
    else
        echo "${size} B"
    fi
}

echo "Rozpoczynam konwersję (Jakość: 90%)..."
echo "----------------------------------------"

for img in *.png *.jpg *.jpeg *.JPG *.PNG; do
    filename="${img%.*}"
    webp_file="$filename.webp"
    
    # Pobierz rozmiar oryginału
    orig_size=$(get_file_size "$img")
    
    # Konwersja
    convert "$img" -quality 90 "$webp_file"
    
    # Pobierz rozmiar po konwersji
    webp_file_size=$(get_file_size "$webp_file")
    
    # Sumuj rozmiary
    total_orig_size=$((total_orig_size + orig_size))
    total_webp_size=$((total_webp_size + webp_file_size))
    
    # Oblicz zysk dla pojedynczego pliku
    saved=$((orig_size - webp_file_size))
    if [ $orig_size -gt 0 ]; then
        percent=$(echo "scale=1; ($saved * 100) / $orig_size" | bc)
    else
        percent=0
    fi
    
    echo "Skonwertowano: $img"
    echo "  Oryginał: $(format_size $orig_size) -> WebP: $(format_size $webp_file_size) | Zmniejszono o: ${percent}%"
    echo ""
    
    ((count++))
done

if [ $count -eq 0 ]; then
    echo "Nie znaleziono plików obrazów."
else
    echo "----------------------------------------"
    echo "PODSUMOWANIE:"
    echo "Przetworzono plików: $count"
    echo "Całkowity rozmiar przed: $(format_size $total_orig_size)"
    echo "Całkowity rozmiar po:    $(format_size $total_webp_size)"
    
    total_saved=$((total_orig_size - total_webp_size))
    if [ $total_orig_size -gt 0 ]; then
        total_percent=$(echo "scale=2; ($total_saved * 100) / $total_orig_size" | bc)
    else
        total_percent=0
    fi
    
    echo "Zaoszczędzono łącznie:   $(format_size $total_saved) ($total_percent%)"
fi